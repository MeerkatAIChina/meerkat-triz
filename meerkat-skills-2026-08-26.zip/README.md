# 智能体集群 · 索引与使用指南

> 本仓库是 [MAPID](https://github.com/MeerkatAIChina/meerkatai-agent) 的 skill pack，MAPID 会从本仓库加载并注册对应的 skills。
>
> 适用场景：各类消费品企业（全品类通用：家电、美妆、食品、服饰、出行工具等）的新品全流程——从用户洞察、技术规划、产品概念、Charter 立项，到卖点包装、销售话术、转化落地。
> 核心方法论主线：**爆点三要素闭环（MCTP 最小可控技术点 × PEP 可感知体验参数 × MCA 最小转化行动）**。

## 仓库结构

```text
skills/<name>/SKILL.md   14 个 Skill，每个 Skill 一个以 name 命名的文件夹，内含 SKILL.md
                         （frontmatter 规范化，全品类通用）
skills/selling-point-packaging/references/
                         卖点包装的独享知识库：aku-library.md
                         （614 条优质卖点提炼为 247 条 AKU、40 个跨品类母题，由 docx 转换为 md）
README.md                本索引与使用指南
```

### Skill 规范

- **目录结构**：`skills/<name>/SKILL.md`，文件夹名必须等于 frontmatter 中的 `name`。
- **name 规则**：1-64 字符，仅小写字母、数字、连字符；不能以连字符开头/结尾；不能连续连字符。
- **frontmatter 必备字段**：
  - `name`：英文小写（见上）
  - `title`：中文名（原名称保留在这里）
  - `description`：一句话说明做什么 + 触发词/关键词
  - `type: skill`
  - `date`：创建/更新日期

> 2026-08-26 通用化更新：全部 Skill 已去赛道绑定、适用于所有消费品企业；文档内行业案例（热水器、亲子代步车、扫地机器人、儿童安全座椅等）保留作示范，使用时按自身品类替换场景与话术。

---

## 一、全景图：Skills 如何串成一条新品流水线

```text
【洞察层】
  interview-transcript-processor ──→ scenario-mining-benefit-extraction
        │                                   │
        ▼                                   ▼
  perceptible-experience-extractor ←── differentiated-value-polishing（洞察+技术合并）
        │
        ▼
【技术层】
  minimum-controllable-technology-point (MCTP)：体验→功能→原理→参数→专利布局
        │
        ▼
【概念层】
  product-concept-house-generator（品类→用户→需求→价值→设计→卖点）
        │
        ▼
【立项层】
  business-success-canvas-generator（5×3 画布）
  charter-writing-suite（完整 Charter 撰写）
        │                      │
        ▼                      ▼
  product-roadmap-excel-generator    industrial-design-brief-writer
        │
        ▼
【卖点与销售层】
  selling-point-packaging（四步：发现→分层→包装→验证）
        │                ↑ 知识支撑：references/aku-library.md
        ▼
  sales-pitch-sop（四步法 SOP）
  minimum-conversion-action (MCA)：触点×价值×动作
        │
        ▼
  sales-scenario-video-script
```

方法论底座（两份研究/知识资产）：

- 六大爆款模型研究（技术奇点/参数竞赛/品类开创/平替颠覆/承诺对赌/场景重做）——用 MCTP×PEP×MCA 框架拆解近年消费品爆款案例的研究底座。原研究以家电行业为样本，模型跨品类通用；该研究文档未随本仓库分发，如需可向猫鼬AI获取。
- `skills/selling-point-packaging/references/aku-library.md`——614 条优质卖点提炼为 247 条 AKU、40 个跨品类母题；AKU = 底层洞察 × 作用机制 × 表达公式三元组。由原 docx 转换为 markdown，是 selling-point-packaging 的独享 reference。

---

## 二、速查索引表

| Skill | title（中文名） | 定位 | 核心输出 | 触发词/关键词 |
|------|--------|------|---------|--------------|
| [interview-transcript-processor](skills/interview-transcript-processor/SKILL.md) | 加工访谈笔录Skill | 洞察层：访谈笔录加工 | 访谈小结(MD) + 用户心智地图(Excel+HTML，7层客户需求地图) | 加工访谈笔录、访谈小结、心智地图 |
| [scenario-mining-benefit-extraction](skills/scenario-mining-benefit-extraction/SKILL.md) | 场景挖掘与产品利益点提炼Skill | 洞察层：双阶段分析 | 品类痛点场景拆解表 → 产品利益点列表 | 场景挖掘、痛点分析、产品利益点 |
| [differentiated-value-polishing](skills/differentiated-value-polishing/SKILL.md) | 差异化价值打磨Skill | 洞察+技术合并 | 8 字段合并表（用户洞察 7 字段 + 技术方案 4 字段，含因果链校验） | 差异化价值、价值打磨 |
| [minimum-controllable-technology-point](skills/minimum-controllable-technology-point/SKILL.md) | 最小可控技术点分析Skill | 技术层：TSCP 三元组 | 10 字段表（体验参数→功能→原理→技术参数→技术问题→MCTP→方案→进化→规划→专利） | 最小可控技术点、技术突破点、专利布局 |
| [perceptible-experience-extractor](skills/perceptible-experience-extractor/SKILL.md) | 可感知体验参数整理Skill | 洞察层：笔录→参数 | 7 字段表（品类/机会点/人群/需求/利益点/可感知体验参数/用户洞察结论） | 可感知体验参数、体验参数整理 |
| [minimum-conversion-action](skills/minimum-conversion-action/SKILL.md) | 最小转化动作Skill | 销售层：MCA 三元组 | 最小转化动作单元库（触点C×价值V×动作A）+ 效果看板 | 最小转化动作、转化、触点设计 |
| [product-concept-house-generator](skills/product-concept-house-generator/SKILL.md) | 产品概念屋内容生成Skill | 概念层：8 步多角色协作 | 完整产品概念屋（品类→用户→3-5核心需求→价值维度→设计要求→卖点Slogan） | 产品概念屋、概念生成、JTBD |
| [product-roadmap-excel-generator](skills/product-roadmap-excel-generator/SKILL.md) | 产品路标规划Excel生成器 | 规划层 | 需求路标+产品路标 Excel（P0-P3 优先级、三路标互锁） | 路标规划、Roadmap Excel |
| [industrial-design-brief-writer](skills/industrial-design-brief-writer/SKILL.md) | 工业设计Brief撰写Skill | 设计层 | 课题任务书/项目任务书（7 模块 Brief） | 工业设计Brief、设计任务书 |
| [charter-writing-suite](skills/charter-writing-suite/SKILL.md) | Charter Skill库 - 增强版 | 立项层：Charter 撰写 | 可评审 Charter 全文（5 种模式：全文/单章/升档/缺口诊断/一页纸） | Charter 撰写、产品立项文档 |
| [business-success-canvas-generator](skills/business-success-canvas-generator/SKILL.md) | 产品商业成功画布生成器 | 立项层：画布工具 | 5×3 商业成功画布（长洋葱式填写） | Charter、商业成功画布 |
| [selling-point-packaging](skills/selling-point-packaging/SKILL.md) | 新品卖点包装方法论 | 卖点层：方法论 | 四步卖点包装（发现→分层→包装→验证），全品类通用（案例以家电行业为例） | 卖点包装、卖点提炼 |
| [sales-pitch-sop](skills/sales-pitch-sop/SKILL.md) | 销售流程卖点话术Skill（优化版） | 销售层：话术 SOP | 四步销售 SOP（喜欢→挖痛点→立价值→促成交）+ FABE 话术 | 销售话术、导购 SOP |
| [sales-scenario-video-script](skills/sales-scenario-video-script/SKILL.md) | 销售场景化卖点视频拍摄Skill | 销售层：视频脚本 | 场景化卖点视频分镜脚本（四类视频矩阵） | 卖点视频、拍摄脚本 |
| — ([aku-library.md](skills/selling-point-packaging/references/aku-library.md)) | 消费品优质卖点AKU原子知识单元总库 | 知识库（selling-point-packaging 独享） | 247 条 AKU、40 母题、20 种作用机制、五步提炼法 | AKU、卖点库、母题 |

---

## 三、分 Skill 使用说明

### interview-transcript-processor（洞察层入口）

**做什么**：把原始访谈笔录（录音转文字）加工为结构化洞察。三步流程：内容清洗与结构化 → 按猫鼬工厂模板生成访谈小结 → 构建用户心智地图。

**输入**：原始访谈笔录 + 访谈背景（项目名称/主题/目标用户/目的）。

**输出**：① 访谈小结（Markdown，含 WHO/WHAT/Key Aha Moment/创新启发四段）；② Excel 心智地图（4 Sheet：客户需求地图主表、场景-任务-情绪矩阵、决策因子权重、五感评分）；③ HTML 可视化（7 层客户需求地图 + 雷达图/情绪曲线/词云）。

**要点**：60 分钟标准加工节奏；Aha Moment 必须有冲突性或反直觉；心智地图 7 层 = 价值观→心理意义→场景化任务→判别标准→情绪→成果→五感，自上而下拆解、自下而上验证。

**下游**：结论可直接喂给 scenario-mining-benefit-extraction、perceptible-experience-extractor。

### scenario-mining-benefit-extraction（洞察层）

**做什么**：双阶段工具。阶段一（用户体验策略师角色）：从品类价值出发识别摩擦点，反推时间/地点/人物，输出「品类痛点场景拆解表」；阶段二（产品经理角色）：把痛点+需求期望转化为产品利益点。

**输入**：`产品品类={名称}` + `产品价值点及拆解要求={核心价值}`。

**输出**：8 列场景表（序号/时间/地点/人物/场景描述/任务/痛点/需求期望）→ 利益点列表（每个利益点含对应场景/痛点/期望）。

**要点**：两阶段可拆开用——只要场景拆解停在阶段一；已有场景表可直接进阶段二。每个场景至少对应一个利益点，利益点要具体可感知。

### minimum-controllable-technology-point（技术层核心）

**做什么**：TSCP = （技术手段T，利益点B，控制机制C），技术创新的最小战略单元。9 步法从可感知体验参数一路推导到专利布局。

**输入**：产品信息（名称/品类/人群/核心体验）+ 可选（用户洞察、现有技术、约束条件）。

**输出**：10 字段 Markdown 表——可感知体验参数、功能、原理、技术参数、技术问题（TRIZ矛盾）、最小可控技术点、技术方案（40发明原理）、技术进化（11大趋势）、技术规划、专利布局。

**要点**：内置自洽校验清单与 TSCP 强度评分（≥8 优先投入 / <4 放弃）；四大误区——技术越强越好、技术点越多越好、专利越多越好、技术规划是研发的事。文内含高速吹风机、降噪耳机两个完整案例 + TRIZ 原理速查表。

**上下游**：上游吃 perceptible-experience-extractor 的体验参数；下游输出给专利分析、三路标对齐（product-roadmap-excel-generator）。

### perceptible-experience-extractor（洞察→技术的翻译器）

**做什么**：从访谈笔录挖掘深层真相，7 步工作流（提取→画像→场景拆解→利益点→体验量化→洞察闭环→数据核验）。

**输出**：7 字段表（品类/机会点/人群/需求/利益点/可感知体验参数/用户洞察结论）。

**要点**：机会点必须基于「用户行为已变、供给未变」的断层；需求必须区分表层/深层；体验参数禁止「提升/改善/优化」等模糊动词，必须含数字+时间+感官描述；洞察结论必须是反常识真相。含花西子雕花口红、智能保温杯两个案例。

### minimum-conversion-action（销售层：MCA）

**做什么**：MCA = （触点C，价值传递V，转化动作A），把销售从「阶段管理」变为「动作管理」。

**输出**：销售阶段地图 → 触点清单 → 价值传递方案 → 转化动作设计 → MCA 单元库 → 效果看板（触达/共鸣/转化率/ROI）。

**要点**：附六类转化动作（认知→推荐）与六大触发机制（限时优惠/从众/稀缺/零风险/对比/场景代入）；评分 ≥8 规模化复制、<4 废弃。含门店试用/试驾、详情页首屏、社群种草三个场景示例。

### product-concept-house-generator（概念层）

**做什么**：8 步多角色协作（市场分析师→用户研究员→产品策略顾问→产品策略专家→高级产品设计师→营销文案专家→循环→汇总），应用 JTBD + 贝恩 B2C 价值要素金字塔。

**输入**：产品机会描述（必需）+ 产品机会需求（可选）。

**输出**：完整概念屋 Markdown——目标品类、人群画像、3-5 个核心需求（各配 ≤15 字 Slogan、价值维度、产品开发设计要求）+ 概念屋总览表。

**要点**：中间步骤输出 JSON 便于流转；核心需求 4/5 不存在时输出「不存在」并跳过；需求排序优先品类相关性而非金字塔层级。

### business-success-canvas-generator（立项层）

**做什么**：Charter 的 5×3 矩阵画布（核心竞争思路/产品定位/产品方案/GTM方案/目标体系 × 战术-执行三行），长洋葱式填写：核心价值主张（洋葱芯）→ 竞争力模型 → 商业方案体系，禁止延长线思维（直接抄竞品）。

**适用**：Charter 工作坊引导、单产品立项推演。与 charter-writing-suite 配合：先用画布发散，再用 Charter 撰写器落成文档。

### charter-writing-suite（立项层主力）

**做什么**：完整 Skill 集合，覆盖市场洞察到执行落地全流程。5 种处理模式：A 全文填写 / B 单章节填写 / C 已有内容升档 / D 缺口诊断（草案+假设+待验证项）/ E 一页纸提炼。

**章节框架**：基本概念→战略目标（三重定位法）→Charter一页纸→市场分析（容量公式：存量保有量×年替代率+潜在用户×年渗透率）→竞品分析（五维度）→用户洞察（灵魂拷问6问+卡诺模型）→产品路标→GTM→财务测算。

**写作铁律**：结论先行、不写空话、所有数字标注来源（[用户提供]/[历史数据]/[竞品对标]/[公式推算]/[行业估算]/[待验证]）、跨章节一致（用户/场景/价格带/价值主张/目标/路标前后对齐）、表格尽量填满。

### product-roadmap-excel-generator（规划层）

**做什么**：将需求/产品路标文档转为结构化 Excel——Sheet1 需求路标汇总、Sheet2 产品路标汇总、Sheet3+ 各产品系列时间轴；P0-P3 优先级、高中低风险颜色标记、产品/技术/设计三路标互锁。

**输入**：需求路标文档 + 产品路标文档。需求来源六类（用户洞察/竞品/技术/设计/战略/运营反馈）各有权重。

### industrial-design-brief-writer（设计层）

**做什么**：生成课题任务书（探索阶段 7 模块）或项目任务书（执行阶段 7 模块），含各模块撰写公式与示例。

**要点**：产品定位公式「为[人群]设计[产品]，通过[差异点]解决[痛点]，实现[商业目标]」；设计要求必须具体可衡量（❌要有设计感 → ✅机头厚度≤80mm）；核心卖点分级标注设计指导意义；技术红线必含性能参数+成本约束。

**上游**：吃 product-concept-house-generator、business-success-canvas-generator / charter-writing-suite 的产出；下游交给 ID 设计团队。

### differentiated-value-polishing（洞察+技术一体化）

**做什么**：将零散灵感/观察/技术突破转为结构化战略数据，四步：关键词提取 → 生成用户洞察表+技术方案表 → 因果链校验 → 合并输出。

**输出**：8 字段合并表 = perceptible-experience-extractor 的 7 字段（洞察侧）+ 技术方案 4 字段（技术侧），是两者的「合体加速版」，适合已有明确技术关键词的场景。

### selling-point-packaging（卖点层）

**做什么**：四步法——①卖点发现（产品技术/竞品对比/用户需求三维度，痛点分 L1 表面→L4 潜在四级）；②卖点分层（卖点金字塔）；③卖点包装；④卖点验证。适用于全品类消费品，含大量案例（以家电行业为示例：热水器 AI 洞察、竞品矩阵等）。

**知识支撑**：与本 Skill 自带的 AKU 总库（`references/aku-library.md`）联用——用 40 个母题 + 表达公式直接套写新卖点。

### sales-pitch-sop（销售层）

**做什么**：基于某头部两轮车企王牌导购训练营方法论，把产品卖点信息转为四步销售 SOP：01 让客户喜欢你(40分)→02 挖场景找痛点(30分)→03 立价值带体验(20分)→04 促成交解抗拒(10分)，对应客户购买八阶段。

**输入**：产品卖点信息模板（基础信息/五类核心卖点/一句话slogan/核心竞品）。

**要点**：4S 瞬间亲和力（See/Smile/Shake/Speak）、FABE 价值塑造、试用/试驾转化设计。

### sales-scenario-video-script（销售层）

**做什么**：将卖点转化为四类视频脚本（人设建立/痛点共鸣/卖点演示/异议处理），与销售四步法一一映射。

**核心输入**：场景化卖点提炼表——场景定义公式「时间+地点+人物+做什么+痛点/爽点」，附六大高频场景库（通勤/出游/家庭/商务/社交/极限）与场景-卖点匹配矩阵示例。

**输出**：分镜脚本（含 FABE 话术与证据）。

---

## 四、典型工作流组合（拿来即用）

**组合 A：从访谈到技术规划（洞察驱动创新）**
interview-transcript-processor → perceptible-experience-extractor（7 字段）→ minimum-controllable-technology-point（10 字段）→ product-roadmap-excel-generator。

**组合 B：从机会到立项（概念驱动立项）**
scenario-mining-benefit-extraction（或 product-concept-house-generator 直接起步）→ product-concept-house-generator → business-success-canvas-generator 发散 → charter-writing-suite 撰写成文 → industrial-design-brief-writer。

**组合 C：从卖点到成交（爆点打造）**
六大爆款模型选模型 → selling-point-packaging（配 AKU 总库套母题）→ minimum-conversion-action 设计触点 → sales-pitch-sop → sales-scenario-video-script。

**组合 D：快速诊断（已有产品/初稿）**
differentiated-value-polishing（8 字段合并表，一次打通洞察与技术）→ charter-writing-suite 的模式 C/D（升档或缺口诊断）。

---

## 五、使用注意

1. **三要素语言统一**：MCTP=技术手段×利益点×控制机制（minimum-controllable-technology-point）；PEP=可感知体验参数（perceptible-experience-extractor）；MCA=触点×价值×动作（minimum-conversion-action）。组合 C 中三者必须指向同一个「可感知的瞬间」——一个数字、一个动作或一个承诺。
2. **禁止事项**（各 Skill 共同红线）：禁止捏造用户需求；禁止模糊动词（提升/优化）；技术参数严禁创造、卖点话术可以创造；Charter 数字必须有来源标注。
3. **单个 Skill 投喂时建议只给一份**，避免多角色指令互相干扰（如 scenario-mining-benefit-extraction 的双阶段可分两次投喂）。
4. **全品类通用**：本集群已去赛道绑定，适用于所有消费品企业；文档内行业案例仅供示范，跨品类使用时替换场景、话术与体验触点（如试驾→试妆/试吃/试穿）。

---

*索引生成时间：2026-08-14 · 2026-08-26 全品类通用化更新 + skill pack 规范化（`skills/<name>/SKILL.md` 结构、frontmatter 补全、AKU 知识库由 docx 转 md 并归入 selling-point-packaging 的 references/）*
