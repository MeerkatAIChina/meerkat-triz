# Changelog

本文件按版本记录 meerkat-skills-lawaken 的变更。

## [1.1.0] - 2026-08-26

### 新增
- 为 `lawaken-memory`、`review-criteria-capture` 补充 `.skill-metadata.yaml`（与其余三个 skill 对齐，每个含 4 组中英示例）。
- 为 `kb-question-resolver`、`product-idea-refinery`、`todo-task-executor` 补充 `evals/evals.json`（每个 3 个测试用例），使五个 skill 的测试覆盖一致。
- 新增本 `CHANGELOG.md`。

### 修复
- 修复 `product-idea-refinery` 中硬编码的绝对路径 `~/.qwenworkcn/skills/review-criteria-capture/SKILL.md`，改为读取 `review-criteria-capture` Skill 配置节固化的路径，避免跨机失效。
- 统一桌面端命名：`lawaken-memory` 中的「qm 桌面端」改为「Meerkat 桌面端」，与 README 及仓库口径一致。
- 修复中文文件名文档（`眼镜端功能发布演示SOP.md`）在 macOS BSD `unzip` 下乱码的问题：移入 `docs/`，并在 README 补充解压说明。

### 文档
- 重写 `README.md`，覆盖全部五个 skill 与演示 SOP，补充技能一览表、完整目录结构、口径（宽/严）说明、测试状态与解压说明。

## [1.0.0] - 2026-08-26

- 初始版本：`lawaken-memory`、`review-criteria-capture`、`product-idea-refinery`、`todo-task-executor`、`kb-question-resolver` 五个 skill，及眼镜端功能发布演示 SOP。
