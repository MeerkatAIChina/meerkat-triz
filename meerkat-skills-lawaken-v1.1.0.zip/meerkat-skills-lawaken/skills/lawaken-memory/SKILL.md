---
name: lawaken-memory
description: 查询 AI 眼镜 lawaken 记忆库——录音/对话产生的记忆（AI 总结）、逐句原文片段、记忆包聚合总结。当用户提到"记忆里""之前说过/讨论过""某次会议/对话""录音原文""帮我回忆一下""记忆包"，或需要查证、追溯任何历史对话与会议内容时，必须使用本 skill，不要凭印象回答。
---

# lawaken 记忆查询

AI 眼镜 lawaken 记忆库保存用户录音/对话的三层数据：**记忆**（一段对话场景的 AI 总结）、**原文片段**（逐句转写文本）、**记忆包**（多条记忆的人工分组 + 聚合总结）。查询的核心思路是**先总结、后原文、再聚合**：summary 层信息密度最高、检索最可靠，原文层用来佐证和引用，记忆包层适合跨记忆的主题汇总。

## 工具定位

六个工具由 lawaken memory MCP server 提供，在 Meerkat 桌面端以 `<serverId>_memory_*` 形式暴露（例如 serverId 为 `lawaken-memory-dev` 时，工具名是 `lawaken-memory-dev_memory_list`）。

**调用前先确认工具存在**：在可用工具里找以 `_memory_list` 结尾的工具来确定实际前缀。如果一个都找不到，说明 MCP server 未注册或未启用——直接告诉用户去设置里检查 lawaken MCP 连接，不要假装查询过。

| 工具后缀                        | 用途                            | 何时用                                      |
| ------------------------------- | ------------------------------- | ------------------------------------------- |
| `_memory_list`                  | 分页查询记忆（summary 层）      | **几乎总是第一步**：按关键词/时间找候选记忆 |
| `_memory_get`                   | 按 memory_id 取单条记忆完整内容 | 锁定候选后看完整总结                        |
| `_memory_transcript_search`     | 分页查询原文片段（逐句转写）    | 需要引用原话、核实细节时                    |
| `_memory_package_list`          | 分页查询记忆包                  | 用户问"记忆包"或想做主题汇总时              |
| `_memory_package_get`           | 记忆包详情 + 聚合总结           | 跨多条记忆的总结性回答                      |
| `_memory_package_list_memories` | 分页查询包内记忆                | 从记忆包钻取到单条记忆                      |

各工具的完整参数与返回字段见 [references/data-structures.md](references/data-structures.md)，拿不准字段名时去查，不要猜。

## 查询策略

### 标准路径：总结 → 原文

1. `memory_list` 用 `keyword` 粗筛。keyword 匹配的是 summary 的 title/brief/keywords/text，召回可靠。关键词取用户问题里的**核心实体或专有名词**（如"SPO""盈利目标"），不要整句丢进去。
2. 从结果里挑候选（看 title、brief、时间），需要全貌时 `memory_get` 取完整总结（`summary.text` 是带小标题的结构化纪要）。
3. 需要原话佐证时 `memory_transcript_search`：
    - **指定 `memory_id`**：在该记忆内按时间顺序翻页读原文（`query_mode: memory`），适合"把这段对话的原文找出来"；
    - **只给 `keyword`**：全局检索原文（`query_mode: timeline`）。注意它匹配的是**逐句转写文本**，是口语原文——书面语关键词可能打不中（实测"盈利"在 summary 里有、原文里没有）。打不中时换更口语的同义词，或干脆指定 memory_id 翻页读。

### 时间过滤

`start_time` / `end_time` 格式固定 `yyyy-MM-dd HH:mm:ss`，对应记忆的 `scene_start_time`（对话发生时间）。用户说"上周""8月25号那天"时换算成绝对时间再传。memory_list 和 transcript_search 都支持。

### 记忆包路径：聚合 → 钻取

1. `memory_package_list` 列包（可用 `status: ready` 过滤掉处理中/失败的）；
2. `memory_package_get` 拿聚合总结（`summary.text`，跨包内所有记忆的主题汇总）——用户问"总结一下xx相关的内容"时优先走这里，比自己拼多条记忆更贴；
3. `memory_package_list_memories` 列出包内记忆（带 `sort_order`），需要细节再 `memory_get` 钻取。

### 分页

所有 list 类工具统一：`limit` 1–50（默认建议 10–20），响应带 `has_more` 和 `next_cursor`——`has_more` 为 true 时把 `next_cursor` 原样回传给 `cursor` 参数翻下一页。游标不透明，不要构造或修改。用户要"全部"时逐页拉完再汇总，不要拉一页就当成全部。

### memory_type 注意

`memory_type` 是自由字符串，没有枚举文档（实测见过 `work_other`）。除非用户明确给了类型，否则**不要拿它过滤**——猜错值会直接过滤掉正确结果。可以先用一轮不带类型的查询观察实际出现哪些类型。

## 回答时的约定

- 引用记忆时带上 `memory_id`、标题和发生时间（如"记忆 #1343《最小可控技术点分析（SPO）战略地图定义》，2026-08-26 14:14"），方便用户溯源和继续钻取。
- 引用原文时用引号标出逐字内容并注明时间点（片段自带 `start_time`），与 AI 总结区分开——总结可能遗漏或概括过度，用户要"原话"时必须落到 transcript 层。
- 这是用户的个人记忆数据：只取回答问题所需的部分，不要把无关的记忆内容大段倒出。
- 查不到就直说查不到，并告诉用户试过哪些关键词——方便换词再查，不要编造记忆内容。
