# lawaken memory MCP — 参数与数据结构参考

本文档的字段来自对 dev 环境的实测响应（2026-08-26）。所有响应同时出现在 `structuredContent` 和 text content 里，内容相同。

## 通用约定

- 时间字段一律 `yyyy-MM-dd HH:mm:ss` 字符串（本地时间）。
- 分页统一：`limit`（1–50）+ `cursor`（不透明字符串，原样回传）；响应带 `has_more`（boolean）和 `next_cursor`（无更多时为 null）。
- 所有查询都只返回**当前账号**（API key 对应用户）的数据。

## memory_list — 分页查询记忆

参数：`start_time?` `end_time?` `keyword?` `memory_type?` `cursor?` `limit?`

- `keyword` 匹配 summary 的 title / brief / keywords / text。

返回：`{ items: Memory[], has_more, next_cursor }`

## memory_get — 按 ID 获取记忆

参数：`memory_id`（integer，**必填**）

返回：单个 Memory 对象（结构同下，无分页包装）。

### Memory 对象

| 字段 | 类型 | 说明 |
|---|---|---|
| `memory_id` | integer | 记忆 ID，钻取用 |
| `memory_type` | string | 自由字符串，实测值如 `work_other` |
| `scene_status` | string | 如 `finished` |
| `scene_start_time` / `scene_end_time` | string | 对话发生时间段（时间过滤对应此字段） |
| `audio_start_time` | string | 录音开始时间 |
| `duration_ms` | integer | 时长（毫秒） |
| `language` | string | 如 `zh-CN` |
| `summary_time` | string | 总结生成时间 |
| `summary.title` | string | 记忆标题 |
| `summary.text` | string | 结构化纪要全文（含 `## 内容回顾` `## 关键决策` `## 待办事项` 等小标题，要点后带 `(HH:mm:ss)` 时间点） |
| `summary.brief` | string | 一句话摘要 |
| `summary.keywords` | string | 逗号分隔关键词 |
| `summary.action` | string | 待办（可为空串） |
| `summary.record_time` | string | 记录时间 |
| `summary.scene_length` | string | 如 `short` |
| `summary.scene_title` | string | 场景类型，如 `口头沟通` |

## memory_transcript_search — 分页查询原文片段

参数：`memory_id?` `start_time?` `end_time?` `keyword?` `memory_type?` `cursor?` `limit?`

- 传 `memory_id` → `query_mode: "memory"`：该记忆内按时间序翻页。
- 不传 → `query_mode: "timeline"`：全局检索，`keyword` 匹配逐句转写原文（口语文本，书面关键词可能不命中）。

返回：`{ items: Segment[], has_more, next_cursor, query_mode }`

### Segment 对象

| 字段 | 类型 | 说明 |
|---|---|---|
| `segment_id` | integer | 片段 ID |
| `memory_id` / `memory_title` / `memory_type` | — | 所属记忆 |
| `seq` / `sentence_index` | integer | 段序 / 句序 |
| `text` | string | 逐字原文一句 |
| `start_time` / `end_time` / `duration_ms` | — | 该句的时间 |

## memory_package_list — 分页查询记忆包

参数：`keyword?` `status?`（`ready` / `processing` / `failed`） `cursor?` `limit?`

返回：`{ items: Package[], has_more, next_cursor }`

### Package 对象

| 字段 | 类型 | 说明 |
|---|---|---|
| `package_id` | string | 形如 `memory_package_20260825193048396_1aab10a3` |
| `name` | string | 包名（用户起的） |
| `memory_count` | integer | 包内记忆数 |
| `status` | string | `ready` / `processing` / `failed` |
| `progress` | integer | 0–100 |
| `created_at` / `updated_at` / `summary_time` | string | — |

## memory_package_get — 记忆包详情 + 聚合总结

参数：`package_id`（string，**必填**）

返回：Package 对象 + `summary: { title, text }`——`text` 是跨包内所有记忆的聚合总结（带 `## 总体状态` 等小标题）。

## memory_package_list_memories — 分页查询包内记忆

参数：`package_id`（string，**必填**） `cursor?` `limit?`

返回：`{ items: Memory[]（多一个 sort_order 字段，表示包内顺序）, has_more, next_cursor }`
