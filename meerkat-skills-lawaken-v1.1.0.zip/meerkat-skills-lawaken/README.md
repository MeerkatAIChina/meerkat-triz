# meerkat-skills-lawaken

Meerkat 桌面端的 lawaken 眼镜技能包（skill pack）。让 Agent 把 AI 眼镜端传来的文字自动沉淀为四类可复用资产：**评审标准、产品创意、待办任务、知识问答**，并把它们统一接入 lawaken 记忆库做溯源。

## 技能一览

| Skill | 职责 | 提取口径 | 落地产物 | 示例 | 测试 |
|---|---|---|---|---|---|
| [lawaken-memory](skills/lawaken-memory/SKILL.md) | 查询记忆库：记忆总结、逐句原文、记忆包聚合 | — | 查询回答（带溯源） | ✅ | ✅ 3 条 |
| [review-criteria-capture](skills/review-criteria-capture/SKILL.md) | 从文字提炼评审标准入档 | 宽（宁多勿漏） | 评审标准 md 追加 | ✅ | ✅ 3 条 |
| [product-idea-refinery](skills/product-idea-refinery/SKILL.md) | 创意提取 → 评审打分 → 打磨 → 三件套存档 | 宽（宁多勿漏） | 创意子文件夹 + 索引 | ✅ | ✅ 3 条 |
| [todo-task-executor](skills/todo-task-executor/SKILL.md) | 待办 → 任务 → 按风险分档执行 | 严（宁缺勿滥） | 任务日志 md | ✅ | ✅ 3 条 |
| [kb-question-resolver](skills/kb-question-resolver/SKILL.md) | 问题 → 查库作答 → AKU 式原子卡 | 严（宁缺勿滥） | QA 卡片 + 索引 | ✅ | ✅ 3 条 |

四个资产类 skill 共享同一条上游：文字要么由用户直接贴入，要么通过 `lawaken-memory` 从记忆库拉取（此时必须落到**原文片段层**，不能只读 AI 总结层）。

## 仓库结构

```
skills/
├── lawaken-memory/
│   ├── SKILL.md                      # skill 本体：触发描述 + 查询策略
│   ├── .skill-metadata.yaml          # 示例（查询记忆 / 查原文 / 记忆包 / MCP 未连接）
│   ├── references/
│   │   └── data-structures.md        # 六个 MCP 工具的完整参数与返回字段参考
│   └── evals/evals.json              # 3 个测试用例
├── review-criteria-capture/
│   ├── SKILL.md
│   ├── .skill-metadata.yaml
│   └── evals/evals.json              # 3 个测试用例
├── product-idea-refinery/
│   ├── SKILL.md
│   ├── .skill-metadata.yaml
│   └── evals/evals.json              # 3 个测试用例
├── todo-task-executor/
│   ├── SKILL.md
│   ├── .skill-metadata.yaml
│   └── evals/evals.json              # 3 个测试用例
└── kb-question-resolver/
    ├── SKILL.md
    ├── .skill-metadata.yaml
    └── evals/evals.json              # 3 个测试用例
docs/
└── 眼镜端功能发布演示SOP.md            # 五幕演示脚本 + 现场风险控制 + 检查清单
```

## 工作原理

skill 本身不含任何网络访问能力，它是对已注册 MCP 工具与本地文件的**使用策略指导**：

1. 桌面端通过 streamable-http 接入 lawaken memory MCP，Agent 获得 6 个工具：
   `memory_list` / `memory_get` / `memory_transcript_search` / `memory_package_list` / `memory_package_get` / `memory_package_list_memories`（运行时工具名带 `<serverId>_` 前缀）。
2. 用户说出「帮我回忆一下……」「之前说过……」「某次会议的原话」「记忆包」等话语时，`lawaken-memory` 被触发；说「把会上定的标准记下来」「把聊的创意提炼一下」「把布置的活儿跑起来」「把会上问的问题查一下」时，对应资产 skill 被触发。
3. 四个资产 skill 先取文字（直接贴入，或经 `lawaken-memory` 拉取 summary + 原文片段），再按各自口径提取，最后把产物写回本地文件/文件夹并更新索引，全程带溯源。
4. 每个 skill 坚持**来源纪律**：AI 补全的内容一律标〔推演〕，查不到就写「未查到」，绝不冒充事实。

## 使用前提

桌面端需先注册 lawaken memory MCP server（依赖 ADR-009 的自定义单头认证）：

```json
{
  "mcpServers": {
    "lawaken-memory": {
      "type": "streamable-http",
      "url": "https://dev.lawaken.com/api/memory/mcp",
      "headers": { "X-Lawaken-MCP-Key": "<your-key>" }
    }
  }
}
```

未注册时，skill 会指引 Agent 明确告知用户记忆服务不可用，而不是编造结果。

四个资产 skill 各自依赖一个**本地路径配置**（评审标准文档 / 创意存档文件夹 / 任务日志 md / 知识库文件夹），首次使用时会询问用户并固化到 SKILL.md 的「配置」节。

## 集成到桌面端

由 `meerkatai-agent` 仓库的 `deploy/layers/meerkat/skillpacks.conf` 引用本仓库，构建时 `stage-payload.ps1` 将 `skills/` 快照打包进桌面端安装包。

## 测试

每个 skill 的 `evals/evals.json` 各含 3 个测试用例，按 skill-creator 流程做 with-skill / baseline 双跑对比评审。测试覆盖三类场景：贴入文字的提取/归档正确性、纯闲聊（无信号）时的空结果、以及指向会议但 MCP 未连接时的诚实兜底。第一轮 `lawaken-memory` 结果：通过率 100%。

## 解压说明

本仓库含中文文件名的文档（`docs/眼镜端功能发布演示SOP.md`）。请用 Python 或 Info-ZIP 解压以正确还原中文名：

```bash
# Python（推荐，macOS / Linux / Windows 通用）
python -m zipfile -e meerkat-skills-lawaken-v1.1.0.zip .

# 或 Info-ZIP
unzip -O UTF-8 meerkat-skills-lawaken-v1.1.0.zip
```

macOS 自带的 BSD `unzip` 对中文文件名会乱码，请避免直接使用。
